package fr.usmb.l3info.tp4;

import fr.usmb.l3info.tp4.parser.*;
import java_cup.runtime.Symbol;

public class Main {

    public static void main(String[] argv) throws Exception {
        exemple();
        question1();
        question2();
        question3();
        question4();
        question5();
        question6();
        question7();
    }

    private static void exemple() throws Exception {
        System.out.println("****************** Exemple **************");
        Parser p = new Parser(new TP4Scanner("(a)"));
        Symbol s = p.parse();
        String chaine = (String) s.value;
        System.out.println(chaine);
    }

    private static void question1() {
        System.out.println("****************** Question 1 **************");
        TP4Scanner question1 = new TP4Scanner("1");
        System.out.println(question1.next_token());
    }

    private static void question2() throws Exception {
        System.out.println("****************** Question 2 **************");
        TP4Scanner question2 = new TP4Scanner("a*");
        System.out.println(question2.next_token());
        System.out.println(question2.next_token());
    }

    private static void question3() throws Exception {
        System.out.println("****************** Question 3 **************");
        String texte = "aa.bbb";
        TP4Scanner question3 = new TP4Scanner(texte);
        for (int i = 0; i < texte.length(); i++) {
            System.out.println(question3.next_token());
        }
    }

    private static void question4() {
        System.out.println("****************** Question 4 **************");
        System.out.println("Problème d'ambiguïté");
    }

    private static void question5() throws Exception {
        System.out.println("****************** Question 5 **************");
        String texte = "a + b*.c";
        TP4Scanner question5 = new TP4Scanner(texte);
        for (int i = 0; i < texte.length(); i++) {
            System.out.println(question5.next_token());
        }
    }

    private static void question6() throws Exception {
        System.out.println("****************** Question 6 **************");
        System.out.println("On pourrait proposer l'expression :\n"
                + "expr:e1 expr:e2                {: RESULT = e1 + e2;    :}\n"
                + "\n"
                + "Malheureusement, cette règle peut créer une ambiguïté : par exemple, a+bc peut se lire (a+b)c ou a+(bc).\n"
                + "Puisqu'il n'y a pas de token entre les caractères, on ne peut pas régler l'ambiguïté avec des priorités.\n"
                + "Il faut donc stratifier la grammaire (expr / term / atom).\n");
    }

    private static void question7() throws Exception {
        System.out.println("****************** Question 7 **************");
        tester("a + bc",          "a + bc");
        tester("ab + c",          "ab + c");
        tester("abc*",            "abc*");
        tester("a.b*c + d",       "a.b*c + d");
        tester("(ab + c)*d + e",  "(ab + c)*d + e");
        tester("a + b + c",       "a + b + c");
        tester("a**",             "a**");
        tester("(a + b)*",        "(a + b)*");
        tester("a + b.c*",        "a + b.c*");
    }

    private static void tester(String titre, String expr) {
        System.out.println("--- " + titre + " ---");
        try {
            Parser p = new Parser(new TP4Scanner(expr));
            Symbol s = p.parse();
            System.out.println((String) s.value);
        } catch (Exception e) {
            System.out.println("ERREUR : " + e.getMessage());
        }
    }
}